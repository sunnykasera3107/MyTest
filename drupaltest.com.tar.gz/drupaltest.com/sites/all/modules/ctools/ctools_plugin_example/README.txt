
The CTools Plugin Example is an example for developers of how to CTools
access, argument, content type, context, and relationship plugins.

There are a number of ways to profit from this:

1. The code itself intends to be as simple and self-explanatory as possible. 
   Nothing fancy is attempted: It's just trying to use the plugin API to show
   how it can be used.
   
2. There is a sample panel. You can access it at /ctools_plugin_example/xxxx
   to see how it works.
   
3. There is Advanced Help at admin/advanced_help/ctools_plugin_example.